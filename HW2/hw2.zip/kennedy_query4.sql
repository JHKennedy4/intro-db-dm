#query 4

SELECT firstName, lastName, phoneNumber FROM contact_info WHERE phoneDescription = 'home' OR phoneDescription = 'cell';
