#query 2

SELECT firstName, lastName, jobTitle, department FROM contact_info WHERE companyName = 'Concor International, Inc.';
