#query 3

SELECT firstName, lastName FROM contact_info WHERE state_province != 'CA';
