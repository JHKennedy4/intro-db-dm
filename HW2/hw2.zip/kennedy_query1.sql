#query 1

SELECT firstName, lastName FROM contact_info WHERE lastName = 'Nelson';
